import React from "react";
import { Link, NavLink } from "react-router-dom";

const Header = () => {
  return (
    <div>
      {/* <div className="mdl-layout mdl-js-layout mdl-layout--fixed-header fix-layout"> */}
      {/* <!-- Header --> */}

      <div className="mdl-layout__header-row">
        <div
          className="mdl-layout__drawer-button mdl-layout--small-screen-only"
          aria-label="Toggle menu"
        >
          <i className="material-icons icon icon--open" role="presentation">
            menu
          </i>
          <i className="material-icons icon icon--close" role="presentation">
            close
          </i>
        </div>
        <h1 className="branding">
          <NavLink className="branding-logo" to="/">
            <img
              src="assets/images/logo.png"
              className="mdl-layout-title"
              alt="Xfinityblog"
              height="40"
            />
          </NavLink>
        </h1>

        {/* <!-- Add spacer, to align navigation to the right --> */}
        <div className="mdl-layout-spacer"></div>

        {/* <!-- Navigation. We hide it in small screens. --> */}
        <nav className="mdl-navigation mdl-layout--large-screen-only">
          <div className="dropdown dropdown-header mdl-link">
            <a className="mdl-navigation__link  js-nav-drop-down">
              Header
              <i className="material-icons" role="presentation">
                arrow_drop_down
              </i>
            </a>
            <div className="dropdown-content-header">
              <div className="before-ul">
                <ul>
                  <li>
                    <Link
                      className="nav-drop-down--hover-dark-lime-green"
                      to="/static_header"
                    >
                      <span>Static Header</span>
                    </Link>
                  </li>
                  <li>
                    <NavLink
                      className="nav-drop-down--hover-bright-blue"
                      to="/transparent_header"
                    >
                      <span>Transparent Header</span>
                    </NavLink>
                  </li>
                  <li>
                    <a
                      className="nav-drop-down--hover-soft-yellow"
                      href="index-4.html"
                    >
                      <span>Centered Layout</span>
                    </a>
                  </li>
                  <li>
                    <a
                      className="nav-drop-down--hover-light-blue"
                      href="index-5.html"
                    >
                      <span>Light-color Header</span>
                    </a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className="dropdown dropdown-page mdl-link">
            <a className="mdl-navigation__link">
              Pages
              <i className="material-icons" role="presentation">
                arrow_drop_down
              </i>
            </a>
            <div className="dropdown-content-header">
              <div className="before-ul">
                <ul>
                  <li>
                    <a
                      className="nav-drop-down--hover-dark-lime-green"
                      href="search.html"
                    >
                      <span>Search</span>
                    </a>
                  </li>
                  <li>
                    <a
                      className="nav-drop-down--hover-bright-blue"
                      href="about.html"
                    >
                      <span>About us</span>
                    </a>
                  </li>
                  <li className="sub-menu">
                    <a className="nav-drop-down--hover-soft-yellow">
                      <span>Blog pages</span>
                      <i className="material-icons" role="presentation">
                        arrow_drop_down
                      </i>
                    </a>
                    <ul className="sub-menu-dropdown">
                      <li>
                        <a
                          className="nav-drop-down--hover-dark-lime-green"
                          href="blog-list.html"
                        >
                          <span>Listing Layout</span>
                        </a>
                      </li>
                      <li>
                        <a
                          className="nav-drop-down--hover-bright-blue"
                          href="blog-grid.html"
                        >
                          <span>Grid layout</span>
                        </a>
                      </li>
                      <li>
                        <a
                          className="nav-drop-down--hover-soft-yellow"
                          href="blog-details.html"
                        >
                          <span>Single Blog Post</span>
                        </a>
                      </li>
                    </ul>
                  </li>
                  <li>
                    <a
                      className="nav-drop-down--hoverpure-blue"
                      href="contact.html"
                    >
                      <span>Contact us</span>
                    </a>
                  </li>
                  <li>
                    <a
                      className="nav-drop-down--hover-dark-violet"
                      href="error-404.html"
                    >
                      <span>Error 404 Page</span>
                    </a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className="dropdown dropdown-page-layout mdl-link">
            <a className="mdl-navigation__link">
              Page Layout
              <i className="material-icons" role="presentation">
                arrow_drop_down
              </i>
            </a>
            <div className="dropdown-content-header">
              <div className="before-ul">
                <ul>
                  <li>
                    <a
                      className="nav-drop-down--hover-dark-lime-green"
                      href="full-width.html"
                    >
                      <span>Full Width Page</span>
                    </a>
                  </li>
                  <li>
                    <a
                      className="nav-drop-down--hover-bright-blue"
                      href="boxed.html"
                    >
                      <span>Boxed Page Layout</span>
                    </a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className="dropdown dropdown-footer mdl-link">
            <a className="mdl-navigation__link">
              Footer
              <i className="material-icons" role="presentation">
                arrow_drop_down
              </i>
            </a>
            <div className="dropdown-content-header">
              <div className="before-ul">
                <ul>
                  <li>
                    <a
                      className="nav-drop-down--hover-dark-lime-green"
                      href="index.html"
                    >
                      <span>Default Footer</span>
                    </a>
                  </li>
                  <li>
                    <a
                      className="nav-drop-down--hover-bright-blue"
                      href="footer-two.html"
                    >
                      <span>Footer Two</span>
                    </a>
                  </li>
                  <li>
                    <a
                      className="nav-drop-down--hover-soft-yellow"
                      href="footer-three.html"
                    >
                      <span>Footer Three</span>
                    </a>
                  </li>
                  <li>
                    <a
                      className="nav-drop-down--hoverpure-blue"
                      href="footer-four.html"
                    >
                      <span>Footer Four</span>
                    </a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className="dropdown dropdown-subjects mdl-link">
            <a className="mdl-navigation__link js-nav-drop-down">
              Topics
              <i className="material-icons" role="presentation">
                arrow_drop_down
              </i>
            </a>
            <div className="nav-drop-down__listcontainer">
              <ul className="nav-drop-down__list">
                <li>
                  <a
                    className="nav-drop-down--hover nav-drop-down--hover-entertainment"
                    href="blog-list.html"
                  >
                    <span>Entertainment</span>
                    <div className="nav-drop-downcontainer entertainment">
                      <p className="nav-drop-down__text nav-drop-downcontainer-entertainment">
                        Lorem ipsum dolor sit amet, consectetur adipisicing
                        elit, sed do eiusmod tempor incididunt ut labore et
                        dolore magna aliqua.
                      </p>
                    </div>
                  </a>
                </li>

                <li>
                  <a
                    className="nav-drop-down--hover nav-drop-down--hover-culture"
                    href="blog-list.html"
                  >
                    <span>Culture</span>
                    <div className="nav-drop-downcontainer culture">
                      <p className="nav-drop-down__text nav-drop-downcontainer-culture">
                        Lorem ipsum dolor sit amet, consectetur adipisicing
                        elit, sed do eiusmod tempor incididunt ut labore et
                        dolore magna aliqua.
                      </p>
                    </div>
                  </a>
                </li>

                <li>
                  <a
                    className="nav-drop-down--hover nav-drop-down--hover-tech"
                    href="blog-list.html"
                  >
                    <span>Tech</span>
                    <div className="nav-drop-downcontainer tech">
                      <p className="nav-drop-down__text nav-drop-downcontainer-tech">
                        Lorem ipsum dolor sit amet, consectetur adipisicing
                        elit, sed do eiusmod tempor incididunt ut labore et
                        dolore magna aliqua.
                      </p>
                    </div>
                  </a>
                </li>

                <li>
                  <a
                    className="nav-drop-down--hover nav-drop-down--hover-science"
                    href="blog-list.html"
                  >
                    <span>Science</span>
                    <div className="nav-drop-downcontainer science">
                      <p className="nav-drop-down__text nav-drop-downcontainer-learning-science">
                        Lorem ipsum dolor sit amet, consectetur adipisicing
                        elit, sed do eiusmod tempor incididunt ut labore et
                        dolore magna aliqua.
                      </p>
                    </div>
                  </a>
                </li>

                <li>
                  <a
                    className="nav-drop-down--hover nav-drop-down--hover-gaming"
                    href="blog-list.html"
                  >
                    <span>Gaming</span>
                    <div className="nav-drop-downcontainer gaming">
                      <p className="nav-drop-down__text nav-drop-downcontainer-gaming">
                        Lorem ipsum dolor sit amet, consectetur adipisicing
                        elit, sed do eiusmod tempor incididunt ut labore et
                        dolore magna aliqua.
                      </p>
                    </div>
                  </a>
                </li>

                <li>
                  <a
                    className="nav-drop-down--hover nav-drop-down--hover-business"
                    href="blog-list.html"
                  >
                    <span>Business</span>
                    <div className="nav-drop-downcontainer business">
                      <p className="nav-drop-down__text nav-drop-downcontainer-business">
                        Lorem ipsum dolor sit amet, consectetur adipisicing
                        elit, sed do eiusmod tempor incididunt ut labore et
                        dolore magna aliqua.
                      </p>
                    </div>
                  </a>
                </li>

                <li>
                  <a
                    className="nav-drop-down--hover nav-drop-down--hover-social"
                    href="blog-list.html"
                  >
                    <span>Social</span>
                    <div className="nav-drop-downcontainer social">
                      <p className="nav-drop-down__text nav-drop-downcontainer-social">
                        Lorem ipsum dolor sit amet, consectetur adipisicing
                        elit, sed do eiusmod tempor incididunt ut labore et
                        dolore magna aliqua.
                      </p>
                    </div>
                  </a>
                </li>

                <li>
                  <a
                    className="nav-drop-down--hover nav-drop-down--hover-health"
                    href="blog-list.html"
                  >
                    <span>Health</span>
                    <div className="nav-drop-downcontainer health">
                      <p className="nav-drop-down__text nav-drop-downcontainer-health">
                        Lorem ipsum dolor sit amet, consectetur adipisicing
                        elit, sed do eiusmod tempor incididunt ut labore et
                        dolore magna aliqua.
                      </p>
                    </div>
                  </a>
                </li>
              </ul>
            </div>
          </div>
          <a className="mdl-navigation__link mdl-link" href="style-guide.html">
            Style Guide
          </a>
        </nav>

        <span className="mdl-button mdl-js-button mdl-button--icon js-search-button ">
          <i className="material-icons search-button">search</i>
        </span>
      </div>
      <div className="global-search global-search--hidden">
        <form>
          <div className="mdl-textfield mdl-textfield--full-width mdl-textfield--large mdl-js-textfield global-search__textfield">
            <input
              className="mdl-textfield__input global-search__input"
              id="global-search"
              type="text"
              placeholder="Search"
            />
            <span className="global-search__hint"></span>
            <label
              className="mdl-textfield__label"
              // for="global-search"
            >
              <i
                className="material-icons global-search__icon"
                role="presentation"
              >
                search
              </i>
            </label>
          </div>
        </form>
      </div>
    </div>
  );
};
export default Header;
