import React from "react";
import BlogSectionCards from "./BlogSectionCards";
import CardsData from "./CardsData";

const BlogSection = () => {
  return (
    <div>
      {CardsData.map((val, ind) => {
        return (
          <BlogSectionCards
            key={ind}
            cards_title={val.card_title}
            cards_body={val.card_body}
            cards_action={val.card_actions}
          />
        );
      })}
    </div>
  );
};
export default BlogSection;
