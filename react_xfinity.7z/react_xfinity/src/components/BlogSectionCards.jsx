import React from "react";

const BlogSectionCards = (props) => {
  return (
    <div>
      <div className="mdl-cell mdl-cell--3-col mdl-cell--4-col-tablet">
        <div className="rw-card rw-card--media mdl-card mdl-shadow--2dp">
          <div className="rw-card__img-container"></div>
          <div className="rw-card__content">
            <h2 className="rw-card__title">
              <a>{props.cards_title}</a>
            </h2>
            <div className="rw-card__body">
              <a>{props.cards_body}</a>
            </div>
            <div className="rw-card__actions">
              <span className="rw-card__meta">{props.cards_action}</span>
              <a className="rw-card__end mdl-button mdl-button--colored mdl-js-button mdl-js-ripple-effect">
                <i className="material-icons">arrow_forward</i>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
export default BlogSectionCards;
