import React from "react";

const CardsData = [
  {
    card_title:
      " Neque porro quisquam est qui dolorem ipsum quia dolor sit amet",
    card_body:
      " Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed doeiusmod tempor incididunt ut labore et dolore magna aliqua...",
    card_actions: "July 12, 2018",
  },
  {
    card_title:
      " Neque porro quisquam est qui dolorem ipsum quia dolor sit amet",
    card_body:
      " Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed doeiusmod tempor incididunt ut labore et dolore magna aliqua...",
    card_actions: "June 18, 2018",
  },
  {
    card_title:
      " Neque porro quisquam est qui dolorem ipsum quia dolor sit amet",
    card_body:
      " Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed doeiusmod tempor incididunt ut labore et dolore magna aliqua...",
    card_actions: "June 18, 2018",
  },
  {
    card_title:
      " Neque porro quisquam est qui dolorem ipsum quia dolor sit amet",
    card_body:
      " Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed doeiusmod tempor incididunt ut labore et dolore magna aliqua...",
    card_actions: "May 22, 2018",
  },
];
export default CardsData;
