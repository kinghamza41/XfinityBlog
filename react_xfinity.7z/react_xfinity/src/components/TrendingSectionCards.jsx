import React from "react";

const TrendingSectionCards = () => {
  return (
    <div>
      <div className="mdl-cell mdl-cell--6-col infocus-img-card mdl-cell--4-col-tablet mdl-cell--12-col-mobile">
        <div className=" rw-card rw-card--media rw-card--media-full mdl-card mdl-shadow--2dp">
          <div className="rw-card__img-container"></div>
          <div className="rw-card__content">
            <h2 className="rw-card__title">
              <a>Lorem Ipsum</a>
            </h2>
            <div className="rw-card__body">
              <a>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                eiusmod tempor incididunt ut labore et dolore magna aliqua...
              </a>
            </div>
            <div className="rw-card__actions">
              <span className="rw-card__meta rw-card__meta--blogpost">
                <i className="material-icons">create</i> Blog
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* <!-- Second Card -->  */}
      <div className="mdl-cell mdl-cell--3-col infocus-card mdl-cell--4-col-tablet mdl-cell--12-col-mobile">
        <div className="rw-card rw-card--media mdl-card mdl-shadow--2dp">
          <div className="rw-card__img-container"></div>
          <div className="rw-card__content">
            <h2 className="rw-card__title">
              <a>
                Neque porro quisquam est qui dolorem ipsum quia dolor sit amet,
                consectetur
              </a>
            </h2>
            <div className="rw-card__body">
              <a>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                eiusmod tempor incididunt ut labore et dolore magna aliqua...
              </a>
            </div>
            <div className="rw-card__actions">
              <span className="rw-card__meta rw-card__meta--blogpost">
                <i className="material-icons">create</i> Blog
              </span>
              <a className="rw-card__end mdl-button mdl-button--colored mdl-js-button mdl-js-ripple-effect">
                <i className="material-icons">arrow_forward</i>
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* <!-- Third Card --> */}
      <div className="mdl-cell mdl-cell--3-col infocus-card mdl-cell--4-col-tablet mdl-cell--12-col-mobile">
        <div className="rw-card rw-card--media mdl-card mdl-shadow--2dp">
          <div className="rw-card__img-container"></div>
          <div className="rw-card__content">
            <h2 className="rw-card__title">
              <a>
                Neque porro quisquam est qui dolorem ipsum quia dolor sit amet,
                consectetur
              </a>
            </h2>
            <div className="rw-card__body">
              <a>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                eiusmod tempor incididunt ut labore et dolore magna aliqua...
              </a>
            </div>
            <div className="rw-card__actions">
              <span className="rw-card__meta rw-card__meta--blogpost">
                <i className="material-icons">create</i> Blog
              </span>
              <a className="rw-card__end mdl-button mdl-button--colored mdl-js-button mdl-js-ripple-effect">
                <i className="material-icons">arrow_forward</i>
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* <!-- Fourth card --> */}
      <div className="mdl-cell mdl-cell--3-col infocus-card mdl-cell--4-col-tablet mdl-cell--12-col-mobile">
        <div className="rw-card rw-card--media mdl-card mdl-shadow--2dp">
          <div className="rw-card__img-container"></div>
          <div className="rw-card__content">
            <h2 className="rw-card__title">
              <a>
                Neque porro quisquam est qui dolorem ipsum quia dolor sit amet,
                consectetur
              </a>
            </h2>
            <div className="rw-card__body">
              <a>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                eiusmod tempor incididunt ut labore et dolore magna aliqua...
              </a>
            </div>
            <div className="rw-card__actions">
              <span className="rw-card__meta rw-card__meta--blogpost">
                <i className="material-icons">create</i> Blog
              </span>
              <a className="rw-card__end mdl-button mdl-button--colored mdl-js-button mdl-js-ripple-effect">
                <i className="material-icons">arrow_forward</i>
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* <!--  Card  Five--> */}
      <div className="mdl-cell mdl-cell--3-col infocus-card mdl-cell--4-col-tablet mdl-cell--12-col-mobile">
        <div className="rw-card rw-card--media mdl-card mdl-shadow--2dp">
          <div className="rw-card__img-container"></div>
          <div className="rw-card__content">
            <h2 className="rw-card__title">
              <a>
                Neque porro quisquam est qui dolorem ipsum quia dolor sit amet,
                consectetur
              </a>
            </h2>
            <div className="rw-card__body">
              <a>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                eiusmod tempor incididunt ut labore et dolore magna aliqua...
              </a>
            </div>
            <div className="rw-card__actions">
              <span className="rw-card__meta rw-card__meta--blogpost">
                <i className="material-icons">create</i> Blog
              </span>
              <a className="rw-card__end mdl-button mdl-button--colored mdl-js-button mdl-js-ripple-effect">
                <i className="material-icons">arrow_forward</i>
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* <!-- Card Six --> */}
      <div className="mdl-cell mdl-cell--6-col infocus-img-card mdl-cell--4-col-tablet mdl-cell--12-col-mobile">
        <div className=" rw-card rw-card--media rw-card--media-full mdl-card mdl-shadow--2dp">
          <div className="rw-card__img-container"></div>
          <div className="rw-card__content">
            <h2 className="rw-card__title">
              <a>Lorem Ipsum</a>
            </h2>
            <div className="rw-card__body">
              <a>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                eiusmod tempor incididunt ut labore et dolore magna aliqua...
              </a>
            </div>
            <div className="rw-card__actions">
              <span className="rw-card__meta rw-card__meta--blogpost">
                <i className="material-icons">create</i> Blog
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
export default TrendingSectionCards;
