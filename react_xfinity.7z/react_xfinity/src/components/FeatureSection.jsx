import React from "react";
import CardsData2 from "./CardsData2";
import FeatureSectionCards from "./FeatureSectionCards";

const FeatureSection = () => {
  return (
    <div>
      {CardsData2.map((val, ind) => {
        return (
          <FeatureSectionCards
            key={ind}
            cards_title={val.card_title}
            cards_body={val.card_body}
            cards_action={val.card_actions}
          />
        );
      })}
    </div>
  );
};
export default FeatureSection;
