import React from "react";
import BlogSection from "../components/BlogSection";
import FeatureSection from "../components/FeatureSection";
import TrendingSectionCards from "../components/TrendingSectionCards";
// import Header from "../components/Header";
import { NavLink } from "react-router-dom";

const Common_index = () => {
  return (
    <div>
      {/* <!-- Mobile navigation drawer --> */}
      <div className="mdl-layout__drawer navigation-drawer">
        <nav className="mdl-navigation">
          <ul className="menu">
            <li>
              <NavLink className="mdl-navigation__link" to="/">
                Home
              </NavLink>
            </li>
            <li>
              <a className="mdl-navigation__link navigation-expand">
                Header
                <i className="material-icons" role="presentation">
                  arrow_drop_down
                </i>
              </a>
              <ul className="navigation-drawer__subnav navigation-expand-content">
                <li className="navigation-drawer__subnav-item">
                  <NavLink className="mdl-navigation__link" to="/static_header">
                    Static Header
                  </NavLink>
                </li>

                <li className="navigation-drawer__subnav-item">
                  <a className="mdl-navigation__link" href="index-3.html">
                    Transparent Header
                  </a>
                </li>

                <li className="navigation-drawer__subnav-item">
                  <a className="mdl-navigation__link" href="index-4.html">
                    Centered Layout
                  </a>
                </li>

                <li className="navigation-drawer__subnav-item">
                  <a className="mdl-navigation__link" href="index-5.html">
                    Light_color Header
                  </a>
                </li>
              </ul>
            </li>
            <li>
              <a className="mdl-navigation__link navigation-expand">
                Pages
                <i className="material-icons" role="presentation">
                  arrow_drop_down
                </i>
              </a>
              <ul className="navigation-drawer__subnav navigation-expand-content">
                <li className="navigation-drawer__subnav-item">
                  <a className="mdl-navigation__link" href="search.html">
                    Search
                  </a>
                </li>
                <li className="navigation-drawer__subnav-item">
                  <a className="mdl-navigation__link" href="about.html">
                    About us
                  </a>
                </li>
                <li className="navigation-drawer__subnav-item">
                  <a className="mdl-navigation__link navigation-expand">
                    Blog Pages
                    <i className="material-icons" role="presentation">
                      arrow_drop_down
                    </i>
                  </a>
                  <ul className="navigation-drawer__subnav navigation-expand-content">
                    <li className="navigation-drawer__subnav-item">
                      <a className="mdl-navigation__link" href="blog-list.html">
                        Listing Layout
                      </a>
                    </li>
                    <li className="navigation-drawer__subnav-item">
                      <a className="mdl-navigation__link" href="blog-grid.html">
                        Grid Layout
                      </a>
                    </li>
                    <li className="navigation-drawer__subnav-item">
                      <a
                        className="mdl-navigation__link"
                        href="blog-details.html"
                      >
                        Single Blog Post
                      </a>
                    </li>
                  </ul>
                </li>

                <li className="navigation-drawer__subnav-item">
                  <a className="mdl-navigation__link" href="contact.html">
                    Contact us
                  </a>
                </li>
                <li className="navigation-drawer__subnav-item">
                  <a className="mdl-navigation__link" href="error-404.html">
                    Error 404 Page
                  </a>
                </li>
              </ul>
            </li>
            <li>
              <a className="mdl-navigation__link navigation-expand">
                Page Layout
                <i className="material-icons" role="presentation">
                  arrow_drop_down
                </i>
              </a>
              <ul className="navigation-drawer__subnav navigation-expand-content">
                <li className="navigation-drawer__subnav-item">
                  <a className="mdl-navigation__link" href="full-width.html">
                    Full Width page
                  </a>
                </li>

                <li className="navigation-drawer__subnav-item">
                  <a className="mdl-navigation__link" href="boxed.html">
                    Boxed Layout
                  </a>
                </li>
              </ul>
            </li>
            <li>
              <a className="mdl-navigation__link navigation-expand">
                Footer
                <i className="material-icons" role="presentation">
                  arrow_drop_down
                </i>
              </a>
              <ul className="navigation-drawer__subnav navigation-expand-content">
                <li className="navigation-drawer__subnav-item">
                  <a className="mdl-navigation__link" href="index.html">
                    Default Footer
                  </a>
                </li>

                <li className="navigation-drawer__subnav-item">
                  <a className="mdl-navigation__link" href="footer-two.html">
                    Footer Two
                  </a>
                </li>

                <li className="navigation-drawer__subnav-item">
                  <a className="mdl-navigation__link" href="footer-three.html">
                    Footer Three
                  </a>
                </li>

                <li className="navigation-drawer__subnav-item">
                  <a className="mdl-navigation__link" href="footer-four.html">
                    Footer Four
                  </a>
                </li>
              </ul>
            </li>
            <li>
              <a className="mdl-navigation__link navigation-expand">
                Topics
                <i className="material-icons" role="presentation">
                  arrow_drop_down
                </i>
              </a>
              <ul className="navigation-drawer__subnav navigation-expand-content">
                <li className="navigation-drawer__subnav-item">
                  <a className="mdl-navigation__link" href="blog-list.html">
                    Entertainment
                  </a>
                </li>

                <li className="navigation-drawer__subnav-item">
                  <a className="mdl-navigation__link" href="blog-list.html">
                    Culture
                  </a>
                </li>
                <li className="navigation-drawer__subnav-item">
                  <a className="mdl-navigation__link" href="blog-list.html">
                    Tech
                  </a>
                </li>
                <li className="navigation-drawer__subnav-item">
                  <a className="mdl-navigation__link" href="blog-list.html">
                    Science
                  </a>
                </li>
                <li className="navigation-drawer__subnav-item">
                  <a className="mdl-navigation__link" href="blog-list.html">
                    Gaming
                  </a>
                </li>
                <li className="navigation-drawer__subnav-item">
                  <a className="mdl-navigation__link" href="blog-list.html">
                    Business
                  </a>
                </li>
                <li className="navigation-drawer__subnav-item">
                  <a className="mdl-navigation__link" href="blog-list.html">
                    Social
                  </a>
                </li>
                <li className="navigation-drawer__subnav-item">
                  <a className="mdl-navigation__link" href="blog-list.html">
                    Health
                  </a>
                </li>
              </ul>
            </li>
            <li>
              <a className="mdl-navigation__link" href="style-guide.html">
                Style Guide
              </a>
            </li>
          </ul>
        </nav>
      </div>
      {/* <!-- //Mobile navigation drawer --> */}

      {/* <!-- main content --> */}
      <main className="main-content">
        {/* <!-- Page --> */}
        <div className="home-page">
          {/* <!-- Banner Section --> */}
          <section
            className="section section--hero"
            aria-label="introduction"
            style={{
              backgroundImage: "url(assets/images/home-hero-background.png)",
            }}
          >
            <div className="mdl-grid fixed-width">
              <div className="section__block section__block--left mdl-cell mdl-cell--7-col mdl-cell--12-col-tablet">
                <h2 className="hero__title">Lorem Ipsum.</h2>
                <p className="hero__subtitle">
                  Neque porro quisquam est qui dolorem ipsum quia dolor sit
                  amet, consectetur, adipisci velit.
                </p>
                <a className="hero__subtitle" target="_blank">
                  Learn more about XfinityBlog with Google.
                </a>
              </div>
            </div>
          </section>
          {/* <!-- //Banner Section --> */}

          {/* <!-- Featured Post Section --> */}
          <section className="section section--content section--infocus">
            <div className="mdl-grid rw-card-grid fixed-width">
              {/* <!-- heading --> */}
              <div className="mdl-cell mdl-cell--12-col mdl-cell--12-col-tablet">
                <h2 className="content__title">Featured</h2>
              </div>
              {/* <!--  Cards  --> */}
              <FeatureSection />
            </div>
          </section>
          {/* <!-- //Featured Post Section -->


					<!-- Trending Section --> */}
          <section className="section section--content section--infocus">
            <div className="mdl-grid rw-card-grid fixed-width">
              {/* <!-- heading --> */}
              <div className="mdl-cell mdl-cell--12-col mdl-cell--12-col-tablet">
                <h2 className="content__title">Trending</h2>
              </div>

              {/* <!--  Cards   --> */}
              <TrendingSectionCards />
            </div>
          </section>
          {/* <!-- //Trending Section -->


					<!-- Topics Section --> */}
          <section className="section section--content section--guides get-started">
            <div className="mdl-grid fixed-width">
              <div className="section__block section-block--content-titles mdl-cell mdl-cell--12-col mdl-cell--12-col-tablet get-started--heading">
                <h2 className="content__title">Topics</h2>
                <p className="content__subtitle">
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed
                  do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                </p>
              </div>
              <div className="get-started--subjects">
                <ul className="subject__list">
                  <li>
                    <a
                      className="subject-entertainment-colour-animate subject__list-item"
                      href="blog-list.html"
                    >
                      Entertainment
                    </a>
                    <p>
                      Duis aute irure dolor in reprehenderit in voluptate velit
                      esse cillum dolore eu fugiat nulla pariatur.
                    </p>
                    <div className="subject__list--footer">
                      <a className="rw-card__end mdl-button mdl-button--colored mdl-js-button mdl-js-ripple-effect">
                        <i className="material-icons">arrow_forward</i>
                      </a>
                    </div>
                  </li>
                  <li>
                    <a
                      className="subject-culture-colour-animate subject__list-item"
                      href="blog-list.html"
                    >
                      Culture
                    </a>
                    <p>
                      Duis aute irure dolor in reprehenderit in voluptate velit
                      esse cillum dolore eu fugiat nulla pariatur.
                    </p>
                    <div className="subject__list--footer">
                      <a className="rw-card__end mdl-button mdl-button--colored mdl-js-button mdl-js-ripple-effect">
                        <i className="material-icons">arrow_forward</i>
                      </a>
                    </div>
                  </li>
                  <li>
                    <a
                      className="subject-tech-colour-animate subject__list-item"
                      href="blog-list.html"
                    >
                      Tech
                    </a>
                    <p>
                      Duis aute irure dolor in reprehenderit in voluptate velit
                      esse cillum dolore eu fugiat nulla pariatur.
                    </p>
                    <div className="subject__list--footer">
                      <a className="rw-card__end mdl-button mdl-button--colored mdl-js-button mdl-js-ripple-effect">
                        <i className="material-icons">arrow_forward</i>
                      </a>
                    </div>
                  </li>
                  <li>
                    <a
                      className="subject-science-colour-animate subject__list-item"
                      href="blog-list.html"
                    >
                      Science
                    </a>
                    <p>
                      Duis aute irure dolor in reprehenderit in voluptate velit
                      esse cillum dolore eu fugiat nulla pariatur.
                    </p>
                    <div className="subject__list--footer">
                      <a className="rw-card__end mdl-button mdl-button--colored mdl-js-button mdl-js-ripple-effect">
                        <i className="material-icons">arrow_forward</i>
                      </a>
                    </div>
                  </li>
                  <li>
                    <a
                      className="subject-gaming-colour-animate subject__list-item"
                      href="blog-list.html"
                    >
                      Gaming
                    </a>
                    <p>
                      Duis aute irure dolor in reprehenderit in voluptate velit
                      esse cillum dolore eu fugiat nulla pariatur.
                    </p>
                    <div className="subject__list--footer">
                      <a className="rw-card__end mdl-button mdl-button--colored mdl-js-button mdl-js-ripple-effect">
                        <i className="material-icons">arrow_forward</i>
                      </a>
                    </div>
                  </li>
                  <li>
                    <a
                      className="subject-business-colour-animate subject__list-item"
                      href="blog-list.html"
                    >
                      Business
                    </a>
                    <p>
                      Duis aute irure dolor in reprehenderit in voluptate velit
                      esse cillum dolore eu fugiat nulla pariatur.
                    </p>
                    <div className="subject__list--footer">
                      <a className="rw-card__end mdl-button mdl-button--colored mdl-js-button mdl-js-ripple-effect">
                        <i className="material-icons">arrow_forward</i>
                      </a>
                    </div>
                  </li>
                  <li>
                    <a
                      className="subject-social-colour-animate subject__list-item"
                      href="blog-list.html"
                    >
                      Social
                    </a>
                    <p>
                      Duis aute irure dolor in reprehenderit in voluptate velit
                      esse cillum dolore eu fugiat nulla pariatur.
                    </p>
                    <div className="subject__list--footer">
                      <a className="rw-card__end mdl-button mdl-button--colored mdl-js-button mdl-js-ripple-effect">
                        <i className="material-icons">arrow_forward</i>
                      </a>
                    </div>
                  </li>
                  <li>
                    <a
                      className="subject-health-colour-animate subject__list-item"
                      href="blog-list.html"
                    >
                      Health
                    </a>
                    <p>
                      Duis aute irure dolor in reprehenderit in voluptate velit
                      esse cillum dolore eu fugiat nulla pariatur.
                    </p>
                    <div className="subject__list--footer">
                      <a className="rw-card__end mdl-button mdl-button--colored mdl-js-button mdl-js-ripple-effect">
                        <i className="material-icons">arrow_forward</i>
                      </a>
                    </div>
                  </li>
                </ul>
              </div>
            </div>
          </section>
          {/* <!-- //Topics Section --> */}

          {/* <!-- Blog Section --> */}
          <section className="section section--content section--content-no-separator section--blogs">
            <div className="mdl-grid rw-card-grid fixed-width">
              {/* <!-- heading --> */}
              <div className="mdl-cell mdl-cell--12-col mdl-cell--12-col-tablet">
                <h2 className="content__title">Latest from the blog</h2>
              </div>
              <BlogSection />
            </div>
          </section>
          {/* <!-- //Blog Section -->

					<!-- Instagram posts --> */}
          <div id="instafeed" className="owl-carousel owl-theme">
            {/* <!-- //Instagram posts --> */}
          </div>

          {/* <!-- Pre Footer --> */}
          <div className="section section--pre-footer hide-for-print">
            <div className="sign-up mdl-grid fixed-width">
              <div className="section__block mdl-cell mdl-cell--6-col">
                <p className="sign-up__title">
                  Get the latest content and inspiration from xfinityblog
                </p>
              </div>
              <div className="section__block mdl-cell mdl-cell--6-col">
                <div className="sign-up__form-wrapper">
                  <form className="sign-up__form formbox">
                    <ul className="formbox__errors"></ul>
                    <div className="responsive-input">
                      <div className="mdl-textfield mdl-js-textfield textfield-demo">
                        <input
                          className="mdl-textfield__input"
                          id="email-prefooter"
                          type="text"
                          name="email"
                        />
                        <label
                          className="mdl-textfield__label"
                          htmlFor="email-prefooter"
                        >
                          Email address
                        </label>
                      </div>
                    </div>
                    <label
                      className="formbox-agreement form__checkbox-outer-label mdl-checkbox mdl-js-checkbox mdl-js-ripple-effect"
                      htmlFor="terms-agreement"
                    >
                      <input
                        className="mdl-checkbox__input"
                        id="terms-agreement"
                        type="checkbox"
                        name="accept-terms"
                      />
                      <span className="sign-up__subtitle mdl-checkbox__label">
                        I accept the <a>Terms and Conditions</a> and acknowledge
                        that my information will be used in accordance with
                        xfinityblog's <a>Privacy Policy</a>.
                      </span>
                    </label>
                    <button className="rework-button rework-button--submit mdl-button mdl-js-button mdl-button--raised">
                      Subscribe
                    </button>
                  </form>
                </div>
              </div>
            </div>
          </div>
          {/* <!-- //pre footer --> */}
        </div>
      </main>
      {/* <!-- //Main content --> */}
    </div>
  );
};
export default Common_index;
