import React from "react";

const CardsData2 = [
  {
    card_title: " Lorem Ipsum",
    card_body:
      " Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed doeiusmod tempor incididunt ut labore et dolore magna aliqua...",
    card_actions: "Blog",
  },
  {
    card_title: " Lorem Ipsum",
    card_body:
      " Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed doeiusmod tempor incididunt ut labore et dolore magna aliqua...",
    card_actions: "Blog",
  },
];
export default CardsData2;
