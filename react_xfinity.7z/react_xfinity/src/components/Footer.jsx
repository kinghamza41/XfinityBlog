import React from "react";

const Footer = () => {
  return (
    <div>
      {/* <!-- Mini-footer--> */}

      <footer
        role="contentinfo"
        className="footer mdl-mini-footer hide-for-print"
      >
        <div className="mdl-mini-footer__left-section">
          <div className="mdl-logo">
            <a href="index.html">
              <img
                src="assets/images/logo.png"
                className="mini-footer-logo"
                alt="xfinityblog"
                height="25"
              />
            </a>
          </div>
          <ul className="mdl-mini-footer__link-list">
            <li>
              <a href="about.html">About Blog</a>
            </li>
            <li>
              <a>Privacy & Terms</a>
            </li>
            <li>
              <a href="contact.html">Contact us</a>
            </li>
          </ul>
        </div>
        <div className="mdl-mini-footer__right-section">
          <ul className="mdl-mini-footer__link-list">
            <li>
              <a
                href="#"
                target="_blank"
                title="LinkedIn"
                className="icon-share analytics-event"
                data-analytics-event-category="linkedin"
                data-analytics-event-action="click"
              >
                <svg
                  className="icon-linkedin"
                  width="20px"
                  height="20px"
                  viewBox="1362 824 156 144"
                  version="1.1"
                >
                  <defs>
                    <polygon
                      id="path-1"
                      points="144.002 143.94 0 143.94 0 71.97 0 0 144.002 0"
                    ></polygon>
                  </defs>
                  <g
                    id="In-2C-PMS-2in-R"
                    stroke="none"
                    strokeWidth="1"
                    fill="none"
                    fillRule="evenodd"
                    transform="translate(1362.000000, 824.000000)"
                  >
                    <g id="Group-3">
                      <mask fill="white">
                        {/* <use {xlink:href="#path-1"}></use> */}
                      </mask>
                      <g id="Clip-2"></g>
                      <path
                        d="M133.343,0 L10.629,0 C4.765,0 0,4.648 0,10.379 L0,133.609 C0,139.345 4.765,144 10.629,144 L133.343,144 C139.217,144 144.002,139.345 144.002,133.609 L144.002,10.379 C144.002,4.648 139.217,0 133.343,0"
                        className="linkedin-fill-1 icon-hover icon-fill-light"
                        mask="url(#mask-2)"
                      ></path>
                    </g>
                    <path
                      d="M32.034,19.825 C38.862,19.825 44.411,25.374 44.411,32.205 C44.411,39.041 38.862,44.592 32.034,44.592 C25.188,44.592 19.647,39.041 19.647,32.205 C19.647,25.374 25.188,19.825 32.034,19.825 L32.034,19.825 Z M21.35,122.707 L42.709,122.707 L42.709,53.986 L21.35,53.986 L21.35,122.707 Z"
                      className="linkedin-fill-2 icon-fill-dark"
                    ></path>
                    <path
                      d="M56.104,53.986 L76.593,53.986 L76.593,63.375 L76.877,63.375 C79.727,57.973 86.694,52.276 97.085,52.276 C118.713,52.276 122.706,66.509 122.706,85.012 L122.706,122.707 L101.362,122.707 L101.362,89.288 C101.362,81.315 101.216,71.065 90.264,71.065 C79.149,71.065 77.447,79.747 77.447,88.711 L77.447,122.707 L56.104,122.707 L56.104,53.986"
                      className="linkedin-fill-3 icon-fill-dark"
                    ></path>
                    <path
                      d="M151.269,119.584 L150.595,119.584 L150.595,118.218 L151.449,118.218 C151.89,118.218 152.395,118.29 152.395,118.867 C152.395,119.531 151.886,119.584 151.269,119.584 L151.269,119.584 Z M151.939,119.989 C152.62,119.905 152.976,119.531 152.976,118.9 C152.976,118.131 152.512,117.758 151.556,117.758 L150.016,117.758 L150.016,121.801 L150.595,121.801 L150.595,120.041 L151.31,120.041 L151.326,120.062 L152.433,121.801 L153.053,121.801 L151.862,119.999 L151.939,119.989 L151.939,119.989 Z"
                      id="Fill-6"
                    ></path>
                    <path
                      d="M151.335,123.107 C149.503,123.107 148.068,121.662 148.068,119.783 C148.068,117.909 149.503,116.463 151.335,116.463 C153.165,116.463 154.6,117.909 154.6,119.783 C154.6,121.662 153.165,123.107 151.335,123.107 L151.335,123.107 Z M151.335,115.96 C149.188,115.96 147.505,117.641 147.505,119.783 C147.505,121.931 149.188,123.607 151.335,123.607 C153.48,123.607 155.16,121.931 155.16,119.783 C155.16,117.641 153.48,115.96 151.335,115.96 L151.335,115.96 Z"
                      className="linkedin-fill-4"
                    ></path>
                  </g>
                </svg>
              </a>
            </li>
            <li>
              <a
                href="#"
                target="_blank"
                title="YouTube"
                className="icon-share"
              >
                <svg
                  version="1.1"
                  id="YouTube_Icon"
                  height="20px"
                  width="20px"
                  viewBox="0 0 1024 721"
                >
                  <path
                    className="st0 icon-fill-dark"
                    d="M407,493l276-143L407,206V493z"
                  />
                  <path
                    className="st1"
                    d="M407,206l242,161.6l34-17.6L407,206z"
                  />
                  <g id="youtube">
                    <g>
                      <path
                        className="st2 icon-hover icon-fill-light"
                        d="M1013,156.3c0,0-10-70.4-40.6-101.4C933.6,14.2,890,14,870.1,11.6C727.1,1.3,512.7,1.3,512.7,1.3h-0.4
                                  c0,0-214.4,0-357.4,10.3C135,14,91.4,14.2,52.6,54.9C22,85.9,12,156.3,12,156.3S1.8,238.9,1.8,321.6v77.5
                                  C1.8,481.8,12,564.4,12,564.4s10,70.4,40.6,101.4c38.9,40.7,89.9,39.4,112.6,43.7c81.7,7.8,347.3,10.3,347.3,10.3
                                  s214.6-0.3,357.6-10.7c20-2.4,63.5-2.6,102.3-43.3c30.6-31,40.6-101.4,40.6-101.4s10.2-82.7,10.2-165.3v-77.5
                                  C1023.2,238.9,1013,156.3,1013,156.3z M407,493l0-287l276,144L407,493z"
                      />
                    </g>
                  </g>
                </svg>
              </a>
            </li>
            <li>
              <a href="#" title="Contact" className="icon-share">
                <svg
                  className="icon-email icon-hover icon-fill-light"
                  height="20px"
                  viewBox="0 0 24 24"
                  width="20px"
                >
                  <path d="M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z" />
                  <path d="M0 0h24v24H0z" fill="none" />
                </svg>
              </a>
            </li>
          </ul>
        </div>
      </footer>

      {/* <!-- /Mini footer --> */}
    </div>
  );
};
export default Footer;
