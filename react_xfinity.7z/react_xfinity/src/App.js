import React from "react";
import { Redirect, Route, Switch } from "react-router-dom";
import Home from "./pages/Home";
import Index_2 from "./pages/Index_2";
import Index_3 from "./pages/Index_3";

const App = () => {
  return (
    <div>
      <Switch>
        <Route exact path="/" component={Home} />
        <Route exact path="/static_header" component={Index_2} />
        <Route exact path="/transparent_header" component={Index_3} />
        <Redirect to="/" />
      </Switch>
    </div>
  );
};
export default App;
