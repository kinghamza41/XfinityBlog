import React from "react";
import Footer from "../components/Footer";
import BlogSection from "../components/BlogSection";
import FeatureSection from "../components/FeatureSection";
import TrendingSectionCards from "../components/TrendingSectionCards";
import Header from "../components/Header";
import { NavLink } from "react-router-dom";
import Common_index from "../components/Common_index";

const Home = () => {
  return (
    <div>
      <div className="mdl-layout mdl-js-layout mdl-layout--fixed-header fix-layout">
        {/* <!-- Header --> */}
        <header className="mdl-layout__header">
          <Header />
        </header>

        <Common_index />

        <Footer />
      </div>
    </div>
  );
};
export default Home;
