import React from "react";
import Header from "../components/Header";
import { NavLink } from "react-router-dom";
import Common_index from "../components/Common_index";
import Footer from "../components/Footer";

const Index_3 = () => {
  return (
    <div>
      <div
        className="mdl-layout mdl-js-layout mdl-layout--fixed-header transparent-layout"
        style={{
          backgroundImage:
            "url(assets/images/daniele-levis-pelusi-311022-unsplash.jpg)",
          backgroundRepeat: "no-repeat",
        }}
      >
        {/* <!-- Header --> */}
        <header className="mdl-layout__header mdl-layout__header--scroll static-header">
          <Header />
        </header>
        <Common_index />

        <Footer />
      </div>
    </div>
  );
};
export default Index_3;
