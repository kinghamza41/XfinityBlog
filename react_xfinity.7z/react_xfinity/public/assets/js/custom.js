  
// Instafeed and Owl Carousel
$(document).ready(function() {
  var userFeed = new Instafeed({
    get: 'user',
    userId: '8413729149',
    clientId: ' 59b0f65892484016ade7caf23eb79e39',
    accessToken: '8413729149.1677ed0.9264a7f570734129b31d51ff4175d450',
    resolution: 'standard_resolution',
    after: function () {

      $('.owl-carousel').owlCarousel({

        loop:true,
        autoplay:true,
        autoplayTimeout:1500,
        autoplayHoverPause:true,
        responsive:{
          0:{
            items:1
          },
          600:{
            items:3
          },
          1000:{
            items:5
          }
        }
      });

    },
    template: '<div class="item"><a href="{{link}}" target="_blank" id="{{id}}" ><img class="img" src="{{image}}" /></a></div>',
    sortBy: 'most-recent',

    links: true
  });
  userFeed.run();
});

  

