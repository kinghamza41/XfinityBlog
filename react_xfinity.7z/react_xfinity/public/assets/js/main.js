
// Search Toggle
$(document).ready(function(){
  $(".search-button").click(function(){
    $(".global-search--hidden").toggle();
  });
});


// Navigation drawer menu expanded content
$(document).ready(function(){
	$("ul.menu").find('> li').click(
		function() {
			$(this).find('> ul').slideToggle();
	  });

	  $("ul.navigation-expand-content").find('> li').click(function(e) {
			e.stopPropagation()
			$(this).find('> ul').slideToggle();

  	});
});

// Dialog box
$(document).ready(function () {
      //subject dialog
      $(".filters__title-subject").click(function(){
      	$(".mdl-dialog-subject, .popup-content").show();
      });
      $(".subject-close").click(function(){
      	$(".mdl-dialog-subject, .popup-content").hide();
      }); 


      //tag dialog
      $(".filters__title-tag").click(function(){
      	$(".mdl-dialog-tag").show();
      });
      $(".tag-close").click(function(){
      	$(".mdl-dialog-tag").hide();
      }); 
});


 